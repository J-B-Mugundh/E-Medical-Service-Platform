<?php
 $db = mysqli_connect('localhost', 'root', 'vijai1234@') or
        die ('Unable to connect. Check your connection parameters.');
        mysqli_select_db($db, 'adp' ) or die(mysqli_error($db));
?>